//++++++++++++++++++++++++++++LIBRARIEs SECTION+++++++++++++++++++++++++++++++++
#include "main.h"
#include <xc.h>
#include <stdint.h>
#include "lcd.h"
#include <stdio.h> 

//++++++++++++++++++++++++++++DIRECTIVEs SECTION++++++++++++++++++++++++++++++++
#define _XTAL_FREQ 16000000

// Constantes
const uint8_t twentyMS = 20;
const uint8_t twoHundMS = 200;
const uint8_t limSLeft = 5;
const uint8_t posR0C0 = 0x80;
const uint8_t posR0C5 = 0x85;
const uint8_t posR1C0 = 0xC0;
const uint8_t notKey = 0xFF;

// Estados de la calculadora
typedef enum {
    WAITING_OPERAND1,
    WAITING_OPERATOR,
    WAITING_OPERAND2,
    SHOWING_RESULT
} CalcState;

//+++++++++++++++++++++++++++++++ISRs SECTION+++++++++++++++++++++++++++++++++++
__interrupt(high_priority) void high_isr(void) {
    Nop();
}
__interrupt(low_priority) void low_isr(void) {
    Nop();
}

//++++++++++++++++++++++++FUNCTIONs DECLARATION+++++++++++++++++++++++++++++++++
void CLK_Initialize(void);
void PORT_Initialize(void);
uint8_t getKey(void);
void waitKeyRelease(void);
int8_t calculate(uint8_t op1, uint8_t op2, char oper);
void printNumber(int8_t num);
void fancyString(void);

//+++++++++++++++++++++++++++++MAIN SECTION+++++++++++++++++++++++++++++++++++++
void main(void) {
    uint8_t key;
    uint8_t operand1 = 0;
    uint8_t operand2 = 0;
    char operator = ' ';
    int8_t result = 0;
    CalcState state = WAITING_OPERAND1;

    CLK_Initialize();
    PORT_Initialize();
    __delay_ms(100);              // let system stabilize
    LCD_Initialize();
    __delay_ms(200);              // IMPORTANT: allows LCD to properly initialize in Proteus

    fancyString();                // animation before calculator starts

    LCD_Clear();
    LCD_Cursor_ON();

    while (1) {
        key = getKey();

        if (key != notKey) {
            switch (state) {
                case WAITING_OPERAND1:
                    if (key >= '0' && key <= '9') {
                        operand1 = key - '0';
                        LCD_putch(key);
                        LCD_putch(' ');
                        state = WAITING_OPERATOR;
                    }
                    break;

                case WAITING_OPERATOR:
                    if (key == 'A' || key == 'B' || key == 'C' || key == 'D') {
                        switch (key) {
                            case 'A': operator = '+'; break;
                            case 'B': operator = '-'; break;
                            case 'C': operator = '*'; break;
                            case 'D': operator = '/'; break;
                        }
                        LCD_putch(operator);
                        LCD_putch(' ');
                        state = WAITING_OPERAND2;
                    }
                    break;

                case WAITING_OPERAND2:
                    if (key >= '0' && key <= '9') {
                        operand2 = key - '0';
                        LCD_putch(key);
                        state = SHOWING_RESULT;
                    } else if (key == '#') {
                        result = calculate(operand1, operand2, operator);
                        LCD_cmd(posR1C0);
                        printNumber(result);
                    }
                    break;

                case SHOWING_RESULT:
                    if (key == '#') {
                        result = calculate(operand1, operand2, operator);
                        LCD_cmd(posR1C0);
                        printNumber(result);
                    } else if (key == '*') {
                        LCD_Clear();
                        LCD_Cursor_Home();
                        state = WAITING_OPERAND1;
                        operand1 = operand2 = 0;
                        operator = ' ';
                        result = 0;
                    }
                    break;
            }

            waitKeyRelease();
        }
    }
}

//++++++++++++++++++++++++++FUNCTIONs SECTION+++++++++++++++++++++++++++++++++++
void CLK_Initialize(void) {
    OSCCONbits.IRCF = 0b111;  // 16MHz internal oscillator
    SLRCON = 0;               // Normal slew rate
}

void PORT_Initialize(void) {
    // LCD configuration
    ANSELD = 0;               // digital for LCD data lines
    ANSELCbits.ANSC2 = 0;     // RS/EN digital
    LATD = 0;
    TRISD = 0x00;             // all LCD pins as output

    // Keypad configuration
    LATB = 0;
    TRISB = 0b00001111;       // RB0-RB3 input, RB4-RB7 output
    ANSELB &= 0b11110000;     // make RB0-RB3 digital
    WPUB |= 0b00001111;       // enable weak pull-ups
    INTCON2bits.RBPU = 0;     // enable PORTB pull-ups
}

uint8_t getKey(void) {
    //========== COLUMNA 0 (RB4) ==========
    LATB |= 0b11110000;
    LATBbits.LATB4 = 0;

    if (PORTBbits.RB0 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB0 == 1) return notKey; return '1'; }
    if (PORTBbits.RB1 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB1 == 1) return notKey; return '4'; }
    if (PORTBbits.RB2 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB2 == 1) return notKey; return '7'; }
    if (PORTBbits.RB3 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB3 == 1) return notKey; return '*'; }

    //========== COLUMNA 1 (RB5) ==========
    LATB |= 0b11110000;
    LATBbits.LATB5 = 0;

    if (PORTBbits.RB0 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB0 == 1) return notKey; return '2'; }
    if (PORTBbits.RB1 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB1 == 1) return notKey; return '5'; }
    if (PORTBbits.RB2 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB2 == 1) return notKey; return '8'; }
    if (PORTBbits.RB3 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB3 == 1) return notKey; return '0'; }

    //========== COLUMNA 2 (RB6) ==========
    LATB |= 0b11110000;
    LATBbits.LATB6 = 0;

    if (PORTBbits.RB0 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB0 == 1) return notKey; return '3'; }
    if (PORTBbits.RB1 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB1 == 1) return notKey; return '6'; }
    if (PORTBbits.RB2 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB2 == 1) return notKey; return '9'; }
    if (PORTBbits.RB3 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB3 == 1) return notKey; return '#'; }

    //========== COLUMNA 3 (RB7) ==========
    LATB |= 0b11110000;
    LATBbits.LATB7 = 0;

    if (PORTBbits.RB0 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB0 == 1) return notKey; return 'A'; }
    if (PORTBbits.RB1 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB1 == 1) return notKey; return 'B'; }
    if (PORTBbits.RB2 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB2 == 1) return notKey; return 'C'; }
    if (PORTBbits.RB3 == 0) { __delay_ms(twentyMS); if (PORTBbits.RB3 == 1) return notKey; return 'D'; }

    return notKey;
}

void waitKeyRelease(void) {
    while (PORTBbits.RB0 == 0);
    while (PORTBbits.RB1 == 0);
    while (PORTBbits.RB2 == 0);
    while (PORTBbits.RB3 == 0);
}

int8_t calculate(uint8_t op1, uint8_t op2, char oper) {
    int8_t res = 0;
    switch (oper) {
        case '+': res = op1 + op2; break;
        case '-': res = op1 - op2; break;
        case '*': res = op1 * op2; break;
        case '/': res = (op2 != 0) ? op1 / op2 : 0; break;
        default:  res = 0; break;
    }
    return res;
}

void printNumber(int8_t num) {
    char buffer[4];
    if (num < 0) {
        LCD_putch('-');
        num = -num;
    }
    sprintf(buffer, "%02d", num);
    LCD_putstr(buffer);
}

//+++++++++++++++++++++++++++++Fancy Intro++++++++++++++++++++++++++++++++++++++
void fancyString(void) {
    LCD_cmd(posR0C5);
    LCD_putstr("PIC18");
    LCD_Cursor_OFF();

    for (int i = 0; i < limSLeft; i++) {
        __delay_ms(twoHundMS);
        LCD_Cursor_SLeft();
    }

    LCD_Cursor_Home();
    LCD_Clear();
    LCD_putstr("PIC18 Calculator");
    __delay_ms(1000);
}
