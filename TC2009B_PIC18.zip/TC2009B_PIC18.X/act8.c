#include <xc.h>
#include <stdint.h>
#include <stdio.h>

// --- CONFIGURATION BITS (COMPLETOS) ---
// CONFIG1L
#pragma config PLLSEL = PLL3X   // PLL Selection (3x clock multiplier)
#pragma config CFGPLLEN = OFF   // PLL Enable Configuration bit (PLL Disabled (firmware controlled))
#pragma config CPUDIV = NOCLKDIV// CPU System Clock Postscaler (CPU uses system clock (no divide))
#pragma config LS48MHZ = SYS48X8// Low Speed USB mode with 48 MHz system clock (System clock at 48 MHz, USB clock divider is set to 8)

// CONFIG1H
#pragma config FOSC = INTOSCIO  // Oscillator Selection (Internal oscillator, port function on RA6)
#pragma config PCLKEN = ON      // Primary Oscillator Shutdown (Primary oscillator enabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config nPWRTEN = OFF    // Power-up Timer Enable (Power up timer disabled)
#pragma config BOREN = SBORDIS  // Brown-out Reset Enable (BOR enabled in hardware (SBOREN is ignored))
#pragma config BORV = 190       // Brown-out Reset Voltage (BOR set to 1.9V nominal)
#pragma config nLPBOR = OFF     // Low-Power Brown-out Reset (Low-Power Brown-out Reset disabled)

// CONFIG2H
#pragma config WDTEN = OFF      // Watchdog Timer Enable (WDT disabled in hardware (SWDTEN ignored))
#pragma config WDTPS = 32768    // Watchdog Timer Postscaler (1:32768)

// CONFIG3H
#pragma config CCP2MX = RC1     // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<5:0> pins are configured as digital I/O on Reset)
#pragma config T3CMX = RC0      // Timer3 Clock input mux bit (T3CKI is on RC0)
#pragma config SDOMX = RB3      // SDO Output Mux bit (SDO is on RB3)
#pragma config MCLRE = ON       // Master Clear Reset Pin Enable (MCLR pin enabled, RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset (Stack full/underflow will cause Reset)
#pragma config LVP = ON         // Single-Supply ICSP Enable bit (Single-Supply ICSP Enabled) <--- CORREGIDO AQUI
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

#define _XTAL_FREQ 16000000     // 16 MHz

// --- PROTOTYPES ---
void SYSTEM_Initialize(void);
void UART_Initialize(void);
void PWM_Initialize(void);
void PWM_Set_Duty(uint8_t percent);
char KEYPAD_GetKey(void);
void putch(char data);

// --- GLOBAL ---
const uint8_t PWM_PR2 = 249; // Periodo para 4kHz

void main(void) {
    char key;
    uint8_t duty_percent = 0;

    SYSTEM_Initialize();

    // Secuencia de arranque visual (Parpadeo LED 3 veces al 50%)
    for(int i=0; i<3; i++) {
        PWM_Set_Duty(50); // ON
        __delay_ms(200);
        PWM_Set_Duty(0);  // OFF
        __delay_ms(200);
    }

    // Mensaje de bienvenida a UART
    printf("\r\nSystem Ready.\r\n");
    printf("Press 0-9 or * to control LED.\r\n");

    while (1) {
        key = KEYPAD_GetKey();

        if (key != 0) { 
            
            // Asignacion de valores
            switch (key) {
                case '1': duty_percent = 10; break;
                case '2': duty_percent = 20; break;
                case '3': duty_percent = 30; break;
                case '4': duty_percent = 40; break;
                case '5': duty_percent = 50; break;
                case '6': duty_percent = 60; break;
                case '7': duty_percent = 70; break;
                case '8': duty_percent = 80; break;
                case '9': duty_percent = 90; break;
                case '0': duty_percent = 100; break;
                case '*': duty_percent = 0; break;
                default:  duty_percent = 255; break; // Invalido
            }

            if (duty_percent != 255) {
                PWM_Set_Duty(duty_percent);
                printf("Key: %c | PWM: %d%%\r\n", key, duty_percent);
                
                // Esperar a que se suelte la tecla para evitar rebotes multiples
                while(KEYPAD_GetKey() == key); 
                __delay_ms(50); 
            }
        }
    }
}

void SYSTEM_Initialize(void) {
    // 1. Oscilador 16MHz
    OSCCONbits.IRCF = 0b111; 
    OSCCONbits.SCS = 0b00;
    
    // 2. Puertos
    LATA = 0x00; LATB = 0x00; LATC = 0x00;
    
    // CRITICO: Configurar RA4 como ENTRADA (Input) para que no pelee con RC1
    TRISAbits.TRISA4 = 1; 
    
    // Configurar Teclado (PORTB)
    ANSELB = 0x00;      // Digital
    // RB0-RB3 Inputs (Filas), RB4-RB7 Outputs (Cols)
    TRISB = 0b00001111; 
    WPUB = 0b00001111;      // Pull-ups en RB0-RB3
    INTCON2bits.RBPU = 0;   // Habilitar Pull-ups globales
    
    // Configurar UART
    UART_Initialize();
    
    // Configurar PWM
    PWM_Initialize();
}

void UART_Initialize(void) {
    // RC6(TX) y RC7(RX)
    ANSELCbits.ANSC6 = 0;
    ANSELCbits.ANSC7 = 0;
    TRISCbits.TRISC6 = 1; // EUSART TX 
    TRISCbits.TRISC7 = 1; // EUSART RX

    // 9600 Baudios @ 16MHz
    BAUDCON1bits.BRG16 = 1;
    TXSTA1bits.BRGH = 1;
    SPBRGH1 = 0x01;
    SPBRG1 = 0xA0; // 416

    TXSTA1bits.SYNC = 0;
    RCSTA1bits.SPEN = 1;
    TXSTA1bits.TXEN = 1;
    RCSTA1bits.CREN = 1;
}

void PWM_Initialize(void) {
    // Configurar RC1 como salida PWM
    TRISCbits.TRISC1 = 1;
    
    PR2 = PWM_PR2;          // 4kHz
    T2CON = 0b00000000;     // Timer2 OFF pre-config
    CCP2CON = 0b00001100;   // PWM mode
    CCPR2L = 0;
    CCP2CONbits.DC2B = 0;
    
    // Prender Timer2 (Prescaler 4)
    T2CONbits.T2CKPS = 0b01; // 1:4
    T2CONbits.TMR2ON = 1;
    
    while(!PIR1bits.TMR2IF); // Esperar estabilizacion
    
    // Habilitar Salida RC1
    TRISCbits.TRISC1 = 0;
}

void PWM_Set_Duty(uint8_t percent) {
    if(percent > 100) percent = 100;
    // 100% duty = 4 * (PR2 + 1) = 1000 ticks
    uint16_t duty = (uint16_t)percent * 10;
    
    // Correccion del warning: Cast explicito a uint8_t
    CCPR2L = (uint8_t)(duty >> 2);
    CCP2CONbits.DC2B = (duty & 0x03);
}

char KEYPAD_GetKey(void) {
    const char keys[4][4] = {
        {'1','2','3','A'},
        {'4','5','6','B'},
        {'7','8','9','C'},
        {'*','0','#','D'}
    };
    
    LATB |= 0xF0; // Cols en alto
    
    for(uint8_t c=0; c<4; c++) {
        // Activar columna c (Bajo)
        switch(c) {
            case 0: LATBbits.LATB4 = 0; break;
            case 1: LATBbits.LATB5 = 0; break;
            case 2: LATBbits.LATB6 = 0; break;
            case 3: LATBbits.LATB7 = 0; break;
        }
        
        // Leer Filas
        if(!PORTBbits.RB0) { __delay_ms(10); if(!PORTBbits.RB0) return keys[0][c]; }
        if(!PORTBbits.RB1) { __delay_ms(10); if(!PORTBbits.RB1) return keys[1][c]; }
        if(!PORTBbits.RB2) { __delay_ms(10); if(!PORTBbits.RB2) return keys[2][c]; }
        if(!PORTBbits.RB3) { __delay_ms(10); if(!PORTBbits.RB3) return keys[3][c]; }
        
        // Desactivar columna
        switch(c) {
            case 0: LATBbits.LATB4 = 1; break;
            case 1: LATBbits.LATB5 = 1; break;
            case 2: LATBbits.LATB6 = 1; break;
            case 3: LATBbits.LATB7 = 1; break;
        }
    }
    
    return 0;
}

// Redireccion para printf
void putch(char data) {
    while(!TXSTA1bits.TRMT);
    TXREG1 = data;
}