#include "main.h"
#include <xc.h>
#include <stdio.h>

#define BTN_INC   PORTBbits.RB4
#define BTN_SAVE  PORTBbits.RB7

#define _XTAL_FREQ 16000000

void CLK_Initialize(void);
void PORT_Initialize(void);
void UART_Initialize(void);
void UART_WRITE_CHAR(char c);
void UART_WRITE(char *t);
void EEPROM_Write(unsigned char addr, unsigned char value);
unsigned char EEPROM_Read(unsigned char addr);

char buffer[50];

void main(void) {

    unsigned char counter;

    CLK_Initialize();
    PORT_Initialize();
    UART_Initialize();

    counter = EEPROM_Read(0x00);

    if (counter == 0xFF) {   // reinicio por defecto de EEPROM
        counter = 0;
        EEPROM_Write(0x00, counter);
    }

    sprintf(buffer, "Inicio -> Contador = %u\r\n", counter);
    UART_WRITE(buffer);

    while(1) {

        if (!BTN_INC) {
            __delay_ms(20);
            if (!BTN_INC) {
                counter++;
                sprintf(buffer, "Contador = %u\r\n", counter);
                UART_WRITE(buffer);
                while (!BTN_INC);
            }
        }

        if (!BTN_SAVE) {
            __delay_ms(20);
            if (!BTN_SAVE) {
                EEPROM_Write(0x00, counter);
                sprintf(buffer, "EEPROM actualizada: %u\r\n", counter);
                UART_WRITE(buffer);
                while (!BTN_SAVE);
            }
        }
    }
}

void CLK_Initialize(void){
    OSCCONbits.IRCF = 0b111;   //16 MHz
}

void PORT_Initialize(void){
    ANSELB = 0x00;             //RB como digitales
    TRISBbits.RB4 = 1;         //Incremento
    TRISBbits.RB7 = 1;         //Guardar
    TRISCbits.RC6 = 0;         //TX
    TRISCbits.RC7 = 1;         //RX
    INTCON2bits.RBPU = 0;      //Pull-ups ON
    WPUB = 0b10010000;         //RB4 y RB7
}

void UART_Initialize(void){
    BAUDCON1bits.BRG16 = 1;
    TXSTA1bits.BRGH = 1;
    SPBRGH1 = 0x01;
    SPBRG1 = 0xA0;
    TXSTA1bits.SYNC = 0;
    RCSTA1bits.SPEN = 1;
    TXSTA1bits.TXEN = 1;
}

void UART_WRITE_CHAR(char c){
    while (!TXSTA1bits.TRMT);
    TXREG1 = c;
}

void UART_WRITE(char *t){
    while (*t) UART_WRITE_CHAR(*t++);
}

void EEPROM_Write(unsigned char addr, unsigned char value){
    EEADR = addr;
    EEDATA = value;

    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;

    unsigned char gie = INTCONbits.GIE;
    INTCONbits.GIE = 0;

    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;

    INTCONbits.GIE = gie;
    while (EECON1bits.WR);

    EECON1bits.WREN = 0;
}

unsigned char EEPROM_Read(unsigned char addr){
    EEADR = addr;
    EECON1bits.CFGS = 0;
    EECON1bits.EEPGD = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}
