/* 
 * File:   concursoPROTEUS.c
 * Author: armgord
 *
 * Created on November 7, 2025, 8:18 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

