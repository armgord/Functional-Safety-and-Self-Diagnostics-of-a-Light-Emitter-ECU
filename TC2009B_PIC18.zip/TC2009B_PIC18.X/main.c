//++++++++++++++++++++++++++++LIBRARIEs SECTION+++++++++++++++++++++++++++++++++
#include "main.h"
#include <xc.h>
#include <stdint.h>//            unified data types for all XC compilers
//++++++++++++++++++++++++++++DIRECTIVEs SECTION++++++++++++++++++++++++++++++++
//Defines
#define _XTAL_FREQ 16000000//    MACRO for __delay_ms() function
#define ONE_SECOND 1000      
//Global variables, constants
//...
//+++++++++++++++++++++++++++++++ISRs SECTION+++++++++++++++++++++++++++++++++++
//ISR for high-priority... ORG 0x08
__interrupt( high_priority ) void high_isr( void ){
  Nop( ); //Function to consume one Instruction Cycle
}
//ISR for low-priority... ORG 0x18
__interrupt( low_priority ) void low_isr( void ) { 
  Nop( ); //Function to consume one Instruction Cycle
}
//++++++++++++++++++++++++FUNCTIONs DECLARATION+++++++++++++++++++++++++++++++++
void CLK_Initialize( void );
void PORT_Initialize( void );
//+++++++++++++++++++++++++++++MAIN SECTION+++++++++++++++++++++++++++++++++++++
void main( void ){
  uint8_t counter = 0;
  CLK_Initialize( );//                     Clock initializations
  PORT_Initialize( );//                    PORT initializations
  while( 1 ){ 
    if( !PORTBbits.RB4 ){
        __delay_ms(10);
        if(!PORTBbits.RB4 == 0){
        //WRITE THE COUNTER VALUE TO THE LEDs (Upper part of Port A)
            LATA = (uint8_t) (counter << 4);
            counter++; // Increment the binary counter  
            while(!PORTBbits.RB4);
            __delay_ms(10);
        }
        

    }
  }
}
//++++++++++++++++++++++++++FUNCTIONs SECTION+++++++++++++++++++++++++++++++++++
void CLK_Initialize( void ){
  OSCCONbits.IRCF = 0b111;//   set HFINTOSC to 16 MHz
  SLRCON = 0;//                set a standard slew rate in pin PORTS 
}
void PORT_Initialize( void ){
  /*LATAbits.LATA4 = 0; //        clear the RA4 output register
  TRISAbits.TRISA4 = 0;//      set RA4 as output
  LATAbits.LATA5 = 0;
  TRISAbits.TRISA5 = 0;
  LATAbits.LATA6 = 0;
  TRISAbits.TRISA6 = 0;
  LATAbits.LATA7 = 0;
  TRISAbits.TRISA7 = 0;
  */ 
  
  LATA = LATA & 0x0F;
  ANSELA = ANSELA & 0x0F;
  TRISA = TRISA & 0x0F;
  
  TRISBbits.RB4 = 1;
  ANSELBbits.ANSB4 = 0;
  WPUBbits.WPUB4 = 1;
  INTCON2bits.RBPU = 0;
   
}
//+++++++++++++++++++++++++++++++++++END++++++++++++++++++++++++++++++++++++++++