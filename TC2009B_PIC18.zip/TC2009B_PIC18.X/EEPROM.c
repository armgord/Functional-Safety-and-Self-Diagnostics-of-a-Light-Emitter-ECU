/* 
 * File:   EEPROM.c
 * Author: armgord
 *
 * Created on November 21, 2025, 11:28 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <string.h>

#pragma config FOSC = INTOSC
#pragma config PLLEN = OFF
#pragma config WDTEN = OFF
#pragma config XINST = OFF
#pragma config LVP = OFF

#define _XTAL_FREQ 16000000UL

#define BUTTON_INC_PIN PORTAbits.RA5
#define BUTTON_SAVE_PIN PORTCbits.RC3
#define DEBOUNCE_DELAY 50

unsigned char contador = 0;

void UART_Initialize() {
    TRISCbits.TRISC6 = 0;
    TRISCbits.TRISC7 = 1;
    TXSTAbits.BRGH = 1;
    BAUDCONbits.BRG16 = 1;
    SPBRG = 103;
    SPBRGH = 0;
    
    TXSTAbits.TXEN = 1;
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
}

void UART_Transmit(char data) {
    while (!TXSTAbits.TRMT);
    TXREG = data;
}

void UART_Transmit_String(const char* str) {
    for (int i = 0; str[i] != '\0'; i++) {
        UART_Transmit(str[i]);
    }
}

unsigned char EEPROM_Read(unsigned char addr) {
    EEADR = addr;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}

void EEPROM_Write(unsigned char addr, unsigned char value) {
    EEADR = addr;
    EEDATA = value;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;
    
    INTCONbits.GIE = 0;
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    
    while (EECON1bits.WR);
    
    EECON1bits.WREN = 0;
    INTCONbits.GIE = 1;
}

void system_initialize() {
    OSCCONbits.IRCF = 0b111;
    OSCCONbits.SCS = 0b10;
    
    ANSELAbits.ANSA5 = 0;
    ANSELCbits.ANSC3 = 0;
    
    ANSELB = ANSELC = ANSELD = ANSELE = 0;
    
    TRISAbits.TRISA5 = 1;
    TRISCbits.TRISC3 = 1;
    
    UART_Initialize();
    
    contador = EEPROM_Read(0x00);
    
    if (contador == 0xFF) {
        contador = 0;
    }
    
    char buffer[30];
    sprintf(buffer, "Inicio -> Contador = %u\r\n", contador);
    UART_Transmit_String(buffer);
}

void main(void) {
    system_initialize();
    
    unsigned char ultimo_estado_inc = 1;
    unsigned char ultimo_estado_save = 1;

    while (1) {
        
        if (BUTTON_INC_PIN == 0) {
            if (ultimo_estado_inc == 1) {
                __delay_ms(DEBOUNCE_DELAY);
                
                if (BUTTON_INC_PIN == 0) {
                    contador++;
                    
                    char buffer[30];
                    sprintf(buffer, "Contador = %u\r\n", contador);
                    UART_Transmit_String(buffer);
                    
                    ultimo_estado_inc = 0;
                }
            }
        } else {
            ultimo_estado_inc = 1;
        }
        
        if (BUTTON_SAVE_PIN == 0) {
            if (ultimo_estado_save == 1) {
                __delay_ms(DEBOUNCE_DELAY);
                
                if (BUTTON_SAVE_PIN == 0) {
                    
                    EEPROM_Write(0x00, contador);
                    
                    char buffer[40];
                    sprintf(buffer, "Guardar EEPROM: %u\r\n", contador);
                    UART_Transmit_String(buffer);
                    
                    sprintf(buffer, "EEPROM actualizada: %u\r\n", contador);
                    UART_Transmit_String(buffer);
                    
                    ultimo_estado_save = 0;
                }
            }
        } else {
            ultimo_estado_save = 1;
        }
    }
}