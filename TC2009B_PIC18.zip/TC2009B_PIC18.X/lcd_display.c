//++++++++++++++++++++++++++++LIBRARIEs SECTION+++++++++++++++++++++++++++++++++
#include "main.h"
#include <xc.h>
#include <stdint.h>//               unified data types for all XC compilers
#include "lcd.h"
//++++++++++++++++++++++++++++DIRECTIVEs SECTION++++++++++++++++++++++++++++++++
//Defines
#define _XTAL_FREQ 16000000//       MACRO for __delay_ms() function
//Enumerations
//...
//Variables, constants
const uint8_t limSLeft = 5;
const uint8_t twentyMS = 20;
const uint8_t twoHundMS = 200;
const uint8_t posR0C5 = 0x85;
const uint8_t posR1C0 = 0xC0;
const uint8_t notKey = 0xFF;
//+++++++++++++++++++++++++++++++ISRs SECTION+++++++++++++++++++++++++++++++++++
//ISR for high-priority... ORG 0x08
__interrupt( high_priority ) void high_isr( void ){
    Nop( ); //Function to consume one Instruction Cycle
}
//ISR for low-priority... ORG 0x18
__interrupt( low_priority ) void low_isr( void ) { 
    Nop( ); //Function to consume one Instruction Cycle
}
//++++++++++++++++++++++++FUNCTIONs DECLARATION+++++++++++++++++++++++++++++++++
void CLK_Initialize( void );
void PORT_Initialize( void );
uint8_t getKey( void );
void fancyString( void );
//+++++++++++++++++++++++++++++MAIN SECTION+++++++++++++++++++++++++++++++++++++
void main( void ){  
    uint8_t key;
    CLK_Initialize( );//                    Clock initializations
    PORT_Initialize( );//                   PORT initializations
    LCD_Initialize( );//                    LCD initializations
    fancyString( );
    LCD_cmd( posR1C0 );//                   cursor position in Row1, Col0
    LCD_Cursor_ON( );//                     cursor is visible
    while( 1 ){
        key = getKey();//                   call the function to get the key
        if( key != notKey ){//              if a key was returned
            LCD_putch( key );//             write the key character in the LCD        
            while( PORTBbits.RB0 == 0 );
            while( PORTBbits.RB1 == 0 );//  wait until key is released
            while( PORTBbits.RB2 == 0 );//  wait until key is released
            while( PORTBbits.RB3 == 0 );//  wait until key is released

            //  wait until key is released
        }
    }
}
//++++++++++++++++++++++++++FUNCTIONs SECTION+++++++++++++++++++++++++++++++++++
void CLK_Initialize( void ){
    OSCCONbits.IRCF = 0b111;//      set HFINTOSC to 16 MHz
    SLRCON = 0;//                   set a standard slew rate in pin PORTS 
}
void PORT_Initialize( void ){  
    //Pin configurations for the LCD
    ANSELD = 0;//                   enable digital buffer in data port
    ANSELCbits.ANSC2 = 0;//         enable digital buffer in RC2
    //Pin configurations for the Keypad
    LATB = 0;//                     clear PORTB data latches
    TRISB = 0;//                    set PORTB as output
    ANSELB = ANSELB & 0b11110000;// enable digital input buffer in RB0
    TRISB = TRISB | 0b00001111;//   set RB0 as input    
    WPUB = WPUB | 0b00001111;//     connect an internal resistor in pin RB0
    INTCON2bits.RBPU = 0;//         enable the internal pull-ups in PORTB
}
uint8_t getKey( void ){
    //========== COLUMNA 0 (RB4) ==========
    LATB = LATB | 0b11110000;
    LATBbits.LATB4 = 0;
    
    if( PORTBbits.RB0 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 1 ) return notKey;
        return '1';
    }
    if( PORTBbits.RB1 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 1 ) return notKey;
        return '4';
    }
    if( PORTBbits.RB2 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 1 ) return notKey;
        return '7';
    }
    if( PORTBbits.RB3 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 1 ) return notKey;
        return '*';
    }
    
    //========== COLUMNA 1 (RB5) ==========
    LATB = LATB | 0b11110000;
    LATBbits.LATB5 = 0;
    
    if( PORTBbits.RB0 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 1 ) return notKey;
        return '2';
    }
    if( PORTBbits.RB1 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 1 ) return notKey;
        return '5';
    }
    if( PORTBbits.RB2 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 1 ) return notKey;
        return '8';
    }
    if( PORTBbits.RB3 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 1 ) return notKey;
        return '0';
    }
    
    //========== COLUMNA 2 (RB6) ==========
    LATB = LATB | 0b11110000;
    LATBbits.LATB6 = 0;
    
    if( PORTBbits.RB0 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 1 ) return notKey;
        return '3';
    }
    if( PORTBbits.RB1 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 1 ) return notKey;
        return '6';
    }
    if( PORTBbits.RB2 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 1 ) return notKey;
        return '9';
    }
    if( PORTBbits.RB3 == 0 ){  // ? RB3, no RB2
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 1 ) return notKey;
        return '#';
    }
    
    //========== COLUMNA 3 (RB7) ==========
    LATB = LATB | 0b11110000;
    LATBbits.LATB7 = 0;
    
    if( PORTBbits.RB0 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 1 ) return notKey;
        return 'A';
    }
    if( PORTBbits.RB1 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 1 ) return notKey;
        return 'B';
    }
    if( PORTBbits.RB2 == 0 ){
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 1 ) return notKey;
        return 'C';
    }
    if( PORTBbits.RB3 == 0 ){  // ? RB3, no RB2
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 1 ) return notKey;
        return 'D';
    }
    
    return notKey;
}
    
void fancyString( void ){
    LCD_cmd( posR0C5 );//      cursor position in row0, col10
    LCD_putstr( "PIC18" );//   write the string in LCD
    LCD_Cursor_OFF( );//        cursor not visible
    //for-loop to left-shift the string every 200ms by modifying DDRAM positions  
    for( int i = 0; i < limSLeft; i++ ){
        __delay_ms( twoHundMS );
        LCD_Cursor_SLeft( );
    }
    LCD_Cursor_Home( );//       set the cursor to Home to reset DDRAM
    LCD_Clear( );//             clear the string
    LCD_putstr( "PIC18" );//   rewrite the string in row0, col0
}

