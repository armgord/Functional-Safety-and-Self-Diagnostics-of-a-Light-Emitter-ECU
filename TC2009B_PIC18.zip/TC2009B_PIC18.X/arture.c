/*
 * File:                main.c
 * Author:              rahu7p
 * Development board:   Curiosity HPC
 * MCU:                 PIC18f45k50
 * 
 */
//++++++++++++++++++++++++++++LIBRARIEs SECTION+++++++++++++++++++++++++++++++++
#include "main.h"
#include <xc.h>
#include <stdint.h>//               unified data types for all XC compilers
//++++++++++++++++++++++++++++DIRECTIVEs SECTION++++++++++++++++++++++++++++++++
//Defines
#define _XTAL_FREQ 16000000//       MACRO for __delay_ms() function
//Enumerations
//...
//Variables, constants
const uint8_t hNibble = 4;
const uint8_t twentyMS = 20;
const uint8_t notKey = 0xFF;
//+++++++++++++++++++++++++++++++ISRs SECTION+++++++++++++++++++++++++++++++++++
//ISR for high-priority... ORG 0x08
__interrupt( high_priority ) void high_isr( void ){
    Nop( ); //Function to consume one Instruction Cycle
}
//ISR for low-priority... ORG 0x18
__interrupt( low_priority ) void low_isr( void ) { 
    Nop( ); //Function to consume one Instruction Cycle
}
//++++++++++++++++++++++++FUNCTIONs DECLARATION+++++++++++++++++++++++++++++++++
void CLK_Initialize( void );
void PORT_Initialize( void );
uint8_t getKey( void );
//+++++++++++++++++++++++++++++MAIN SECTION+++++++++++++++++++++++++++++++++++++
void main( void ){  
    uint8_t key;
    CLK_Initialize( );//                            Clock initializations
    PORT_Initialize( );//                           PORT initializations
    while( 1 ){  
        key = getKey();//                           call the function to get the Key
        if( key != notKey ){//                      if a Key was returned
            LATA = (uint8_t)( key << hNibble );//   show the value of Key in LEDs          
            while(( PORTB & 0x0F ) != 0x0F );//     wait until Key is released
        }
    }
}
//++++++++++++++++++++++++++FUNCTIONs SECTION+++++++++++++++++++++++++++++++++++
void CLK_Initialize( void ){
    OSCCONbits.IRCF = 0b111;//      set HFINTOSC to 16 MHz
    SLRCON = 0;//                   set a standard slew rate in pin PORTS 
}
void PORT_Initialize( void ){  
    //Pin configurations for LEDs (D5-D2)
    LATA = 0;//                     clear PORTA data latches
    TRISA = TRISA & 0b00001111;//   set RA7-RA4 as output
    //Pin configurations for the Keypad
    LATB = 0;//                     clear PORTB data latches
    TRISB = 0;//                    set PORTB as output
    ANSELB = ANSELB & 0b11110000;// enable digital input buffer in RB3-RB0
    TRISB = TRISB | 0b00001111;//   set RB3-RB0 as input    
    WPUB = WPUB | 0b00001111;//     connect internal resistors in pins RB3-RB0
    INTCON2bits.RBPU = 0;//         enable the internal pull-ups in PORTB
}
uint8_t getKey( void ){
    //=============== COLUMN 0 (RB4) ===============
    LATB = LATB | 0b11110000;//     disable with '1' the columns of the keypad 
    LATBbits.LATB4 = 0;//           enable with '0' the C0
    
    // ROW 0 (RB0)
    if( PORTBbits.RB0 == 0 ){//     if we find the '0' in R0 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB0 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 1;//                 assign a match (R0-C0) value of '1'
    }
    
    // ROW 1 (RB1)
    if( PORTBbits.RB1 == 0 ){//     if we find the '0' in R1 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB1 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 4;//                 assign a match (R1-C0) value of '4'
    }
    
    // ROW 2 (RB2)
    if( PORTBbits.RB2 == 0 ){//     if we find the '0' in R2 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB2 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 7;//                 assign a match (R2-C0) value of '7'
    }
    
    // ROW 3 (RB3)
    if( PORTBbits.RB3 == 0 ){//     if we find the '0' in R3 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB3 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 15;//                assign a match (R3-C0) value of '*' = 15
    }
    
    //=============== COLUMN 1 (RB5) ===============
    LATB = LATB | 0b11110000;//     disable with '1' the columns of the keypad 
    LATBbits.LATB5 = 0;//           enable with '0' the C1
    
    // ROW 0 (RB0)
    if( PORTBbits.RB0 == 0 ){//     if we find the '0' in R0 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB0 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 2;//                 assign a match (R0-C1) value of '2'
    }
    
    // ROW 1 (RB1)
    if( PORTBbits.RB1 == 0 ){//     if we find the '0' in R1 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB1 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 5;//                 assign a match (R1-C1) value of '5'
    }
    
    // ROW 2 (RB2)
    if( PORTBbits.RB2 == 0 ){//     if we find the '0' in R2 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB2 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 8;//                 assign a match (R2-C1) value of '8'
    }
    
    // ROW 3 (RB3)
    if( PORTBbits.RB3 == 0 ){//     if we find the '0' in R3 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB3 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 0;//                 assign a match (R3-C1) value of '0'
    }
    
    //=============== COLUMN 2 (RB6) ===============
    LATB = LATB | 0b11110000;//     disable with '1' the columns of the keypad 
    LATBbits.LATB6 = 0;//           enable with '0' the C2
    
    // ROW 0 (RB0)
    if( PORTBbits.RB0 == 0 ){//     if we find the '0' in R0 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB0 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 3;//                 assign a match (R0-C2) value of '3'
    }
    
    // ROW 1 (RB1)
    if( PORTBbits.RB1 == 0 ){//     if we find the '0' in R1 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB1 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 6;//                 assign a match (R1-C2) value of '6'
    }
    
    // ROW 2 (RB2)
    if( PORTBbits.RB2 == 0 ){//     if we find the '0' in R2 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB2 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 9;//                 assign a match (R2-C2) value of '9'
    }
    
    // ROW 3 (RB3)
    if( PORTBbits.RB3 == 0 ){//     if we find the '0' in R3 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB3 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 14;//                assign a match (R3-C2) value of '#' = 14
    }
    
    //=============== COLUMN 3 (RB7) ===============
    LATB = LATB | 0b11110000;//     disable with '1' the columns of the keypad 
    LATBbits.LATB7 = 0;//           enable with '0' the C3
    
    // ROW 0 (RB0)
    if( PORTBbits.RB0 == 0 ){//     if we find the '0' in R0 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB0 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 10;//                assign a match (R0-C3) value of 'A' = 10
    }
    
    // ROW 1 (RB1)
    if( PORTBbits.RB1 == 0 ){//     if we find the '0' in R1 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB1 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 11;//                assign a match (R1-C3) value of 'B' = 11
    }
    
    // ROW 2 (RB2)
    if( PORTBbits.RB2 == 0 ){//     if we find the '0' in R2 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB2 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 12;//                assign a match (R2-C3) value of 'C' = 12
    }
    
    // ROW 3 (RB3)
    if( PORTBbits.RB3 == 0 ){//     if we find the '0' in R3 
        __delay_ms( twentyMS );//   call a delay to debounce the input
        if( PORTBbits.RB3 == 1 ){// double checking
            return notKey;//        if button was not pressed, no match
        }
        return 13;//                assign a match (R3-C3) value of 'D' = 13
    }
    
    return notKey;
}
//+++++++++++++++++++++++++++++++++++END+++++++++++++++++++++++++++++++++++++++