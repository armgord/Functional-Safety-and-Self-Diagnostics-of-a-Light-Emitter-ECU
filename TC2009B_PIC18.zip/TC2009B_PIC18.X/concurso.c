//++++++++++++++++++++++++++++LIBRARIEs SECTION+++++++++++++++++++++++++++++++++
#include "main.h"      
#include <stdio.h>     
#include <string.h>    
#include <xc.h>
#include <stdint.h>     
#include "lcd.h"       
//++++++++++++++++++++++++++++DIRECTIVEs SECTION++++++++++++++++++++++++++++++++
#define _XTAL_FREQ 16000000
#define NOT_KEY 0xFF        
#define NUM_PREGUNTAS 5     
// Tiempos de delay
const uint8_t limSLeft = 10;
const uint8_t twentyMS = 20;
const uint8_t twoHundMS = 200;
const uint8_t posR0C10 = 0x8A;
const uint8_t posR1C0 = 0xC0;
const uint8_t notKey = 0xFF;

const char *preguntas[NUM_PREGUNTAS] = {
    " El sol es una estrella?",
    " El ajedrez tiene 64 casillas?",
    " La capital de Francia es Berlin?",
    " El Imperio romano cayo en 1492",
    " El PIC es un microcontrolador?"
};

const char respuestas_correctas[NUM_PREGUNTAS] = {'V', 'V', 'F', 'F', 'V'};

//+++++++++++++++++++++++++++++++ISRs SECTION+++++++++++++++++++++++++++++++++++
__interrupt( high_priority ) void high_isr( void ){
    Nop( ); 
}
__interrupt( low_priority ) void low_isr( void ) { 
    Nop( );
}

//++++++++++++++++++++++++FUNCTIONs DECLARATION+++++++++++++++++++++++++++++++++
void CLK_Initialize( void );
void PORT_Initialize( void );
void UART_Initialize( void );
void UART_TransmitByte( uint8_t data );
uint8_t UART_ReceiveByte( void );
uint8_t UART_DataReady( void ); 
uint8_t getKey( void );
void fancyString( void );

void LCD_SetCursor(int row, int col) {
    if (row == 0) {
        LCD_cmd((char)(0x80 + col)); 
    } else if (row == 1) {
        LCD_cmd((char)(0xC0 + col));
    }
}

void LCD_WriteString(const char *s) {
    LCD_putstr((char *)s);
}

char Keypad_GetKey(void) {
    return (char)getKey();
}

void LCD_WriteStringWrap(const char *s) {
    uint8_t i = 0;

    LCD_SetCursor(0, 0);
    
    while (s[i] != '\0') {
        if (i == 16) {
            LCD_SetCursor(1, 0);
        }

        if (i < 32) {
            LCD_putch(s[i]);
        }
        i++;
    }
}

void putch(char txData){
    UART_TransmitByte( txData );
}

uint8_t UART_DataReady( void ) {
    return PIR1bits.RCIF; 
}

//+++++++++++++++++++++++++++++MAIN SECTION+++++++++++++++++++++++++++++++++++++
void main( void ){ 
    char key_pressed;
    char pc_response;
    int correct_answers = 0;
    int i;
    uint8_t key, keyboard;
    
    CLK_Initialize( );
    PORT_Initialize( );
    UART_Initialize( );
    LCD_Initialize( );
    
    fancyString( );
    LCD_Clear();
    LCD_WriteString("CONCURSO PIC");
    LCD_SetCursor(1, 0);
    LCD_WriteString("Presiona '1'");
    LCD_cmd( posR1C0 );
    LCD_Cursor_ON( );
    
    // Esperar a que presionen '1' para empezar
    do {
        key_pressed = Keypad_GetKey();
        if (key_pressed != NOT_KEY) {
            printf("Tecla presionada: %c\r\n", key_pressed); 
            while( PORTBbits.RB0 == 0 ); 
        }
    } while (key_pressed != '1'); 

    // Loop principal - recorre las 5 preguntas
    for (i = 0; i < NUM_PREGUNTAS; i++) {
        
        // Mostrar pregunta en LCD y enviarla por UART
        LCD_Clear(); 
        LCD_WriteStringWrap(preguntas[i]);
        
        printf("\r\n--- Pregunta %d ---\r\n", i + 1);
        printf("%s\r\n", preguntas[i]);
        
        // Esperar respuesta de la PC
        while (!UART_DataReady()); 
        
        pc_response = (char)UART_ReceiveByte();

        // Convertir min�scula a may�scula si es necesario
        if (pc_response >= 'a' && pc_response <= 'z') {
            pc_response = pc_response - ('a' - 'A');
        }
        
        LCD_Clear(); 
        LCD_putch(pc_response); 
        LCD_SetCursor(1, 0);  // Fila 1, no 2 (el LCD solo tiene 2 filas)

        // Validar respuesta
        if (pc_response == respuestas_correctas[i]) {
            correct_answers++;
            LCD_WriteString("CORRECTA!");
            printf("\r\nRespuesta recibida: %c -> Correcta.\r\n", pc_response);
        } else if (pc_response == 'V' || pc_response == 'F') {
            LCD_WriteString("INCORRECTA!");
            printf("\r\nRespuesta recibida: %c -> Incorrecta.\r\n", pc_response);
        } else {
            LCD_WriteString("ERROR DATO!");
            printf("\r\nRespuesta no valida: %c\r\n", pc_response);
        }

        __delay_ms(2000); 
    }

    // Mostrar resultados finales
    LCD_Clear(); 
    LCD_WriteString(" CONCURSO FINAL");
    LCD_SetCursor(1, 0);
    
    printf(" \r\n\r\n---  RESULTADO FINAL ---\r\n");
    printf("Total de Respuestas Correctas: %d de %d\r\n", correct_answers, NUM_PREGUNTAS);
    
    char result_msg[20];
    sprintf(result_msg, "Total: %d/5", correct_answers);
    LCD_WriteString(result_msg);
    printf("---------------------------\r\n");

    while (1); 
}

//++++++++++++++++++++++++++FUNCTIONs SECTION+++++++++++++++++++++++++++++++++++
void CLK_Initialize( void ){
    OSCCONbits.IRCF = 0b111;
    SLRCON = 0;
}

void PORT_Initialize( void ){  
    ANSELD = 0;
    ANSELCbits.ANSC2 = 0;
    
    LATB = 0;
    TRISB = 0b00001111; // RB0-RB3 entradas (filas), RB4-RB7 salidas (columnas)
    ANSELB = 0; 
    INTCON2bits.RBPU = 0; // Pull-ups activados
}

void UART_Initialize( void ){
    // Configurar pines TX y RX
    ANSELCbits.ANSC6 = 0;
    TRISCbits.TRISC6 = 1;
    ANSELCbits.ANSC7 = 0;
    TRISCbits.TRISC7 = 1;
    
    // Baudrate 9600
    BAUDCON1bits.BRG16 = 1;
    TXSTA1bits.BRGH = 1;
    SPBRGH1 = 0x01;       
    SPBRG1 = 0xA0;
    
    // Inicializar UART
    TXSTA1bits.SYNC = 0;
    RCSTA1bits.SPEN = 1;
    TXSTA1bits.TXEN = 1;
    RCSTA1bits.CREN = 1;
}

void UART_TransmitByte( uint8_t data ){
    while( TXSTA1bits.TRMT == 0 );
    TXREG1 = data;
}

uint8_t UART_ReceiveByte( void ){
    uint8_t data = 0xFF;
    if( PIR1bits.RCIF == 1 ){
        RCSTA1bits.CREN = 0;
        data = RCREG1;
        RCSTA1bits.CREN = 1;
    }
    return data;
}

uint8_t getKey( void ){
    uint8_t key_val = NOT_KEY;
    
    // Mapeo del teclado 4x4
    //     COL0  COL1  COL2  COL3
    // R0:  1     2     3     A
    // R1:  4     5     6     B
    // R2:  7     8     9     C
    // R3:  *     0     #     D
    
    // Revisar columna 0 (RB4)
    LATB = 0b11100000; 
    __delay_ms(1); 
    
    if( PORTBbits.RB0 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 0 ){
            key_val = '1';
            while (PORTBbits.RB0 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB1 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 0 ){
            key_val = '4';
            while (PORTBbits.RB1 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB2 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 0 ){
            key_val = '7';
            while (PORTBbits.RB2 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB3 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 0 ){
            key_val = '*';
            while (PORTBbits.RB3 == 0);
            return key_val;
        }
    }
    
    // Revisar columna 1 (RB5)
    LATB = 0b11010000;
    __delay_ms(1);
    
    if( PORTBbits.RB0 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 0 ){
            key_val = '2';
            while (PORTBbits.RB0 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB1 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 0 ){
            key_val = '5';
            while (PORTBbits.RB1 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB2 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 0 ){
            key_val = '8';
            while (PORTBbits.RB2 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB3 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 0 ){
            key_val = '0';
            while (PORTBbits.RB3 == 0);
            return key_val;
        }
    }
    
    // Revisar columna 2 (RB6)
    LATB = 0b10110000;
    __delay_ms(1);
    
    if( PORTBbits.RB0 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 0 ){
            key_val = '3';
            while (PORTBbits.RB0 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB1 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 0 ){
            key_val = '6';
            while (PORTBbits.RB1 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB2 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 0 ){
            key_val = '9';
            while (PORTBbits.RB2 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB3 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 0 ){
            key_val = '#';
            while (PORTBbits.RB3 == 0);
            return key_val;
        }
    }
    
    // Revisar columna 3 (RB7)
    LATB = 0b01110000;
    __delay_ms(1);
    
    if( PORTBbits.RB0 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB0 == 0 ){
            key_val = 'A';
            while (PORTBbits.RB0 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB1 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB1 == 0 ){
            key_val = 'B';
            while (PORTBbits.RB1 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB2 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB2 == 0 ){
            key_val = 'C';
            while (PORTBbits.RB2 == 0);
            return key_val;
        }
    }
    if( PORTBbits.RB3 == 0 ){ 
        __delay_ms( twentyMS );
        if( PORTBbits.RB3 == 0 ){
            key_val = 'D';
            while (PORTBbits.RB3 == 0);
            return key_val;
        }
    }
    
    return key_val;
}

void fancyString( void ){
    LCD_cmd( posR0C10 );
    LCD_putstr( " TC2009B" );
    LCD_Cursor_OFF( );
    
    // Desplazar el texto a la izquierda
    for( int i = 0; i < limSLeft; i++ ){
        __delay_ms( twoHundMS );
        LCD_Cursor_SLeft( );
    }
    LCD_Cursor_Home( );
    LCD_Clear( );
    LCD_putstr( " TC2009B" );
}
//+++++++++++++++++++++++++++++++++++END++++++++++++++++++++++++++++++++++++++++